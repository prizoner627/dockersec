import requests
import time
import click
import json

from json.decoder import JSONDecodeError
from subprocess import call

def check():
    rc = call("./host_configuration/check.sh", shell=True)
            

@click.command()							
@click.argument('keyword', type=str)
@click.option('--outfile', type=str, default="sample.txt", help='Output file name')

def main(keyword, outfile):
    check()

if __name__ == '__main__':
    main()