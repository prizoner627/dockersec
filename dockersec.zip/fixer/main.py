
import click
from pprint import pprint
from dockerfile_parse import DockerfileParser

from json.decoder import JSONDecodeError
from bs4 import BeautifulSoup

@click.command()							
@click.option('--dockerfile', type=str, default="./samples/Dockerfile", help='Dockerfile location')
@click.option('--composefile', type=str, default="./samples/docker-compose.yml", help='Docker-compose location')

def main(dockerfile,composefile):
    if dockerfile:
        scanDockerFile(dockerfile)

    if composefile:
        scanComposeFile(composefile)

def scanDockerFile(dockerfile):
    print(dockerfile)
    dfp = DockerfileParser()

    #open file for reading
    with open(dockerfile, 'r') as f:
        data = f.read()
        dfp.content = data
        pprint(dfp.baseimage)

    if dfp.baseimage is not None:
        #scan base images for vulns
        pprint(dfp.structure)
        #set baseimage to latest 
        baseimage = dfp.baseimage.split(":")
        setLatest = baseimage[0] + ":latest"
        # print(setLatest)
        dfp.baseimage = setLatest 
        # print(dfp.content)

        #write to new  file
        with open('./Dockerfile', 'w') as outfile:
            outfile.write(dfp.content)
        
def scanComposeFile(composefile):
    print(composefile)
    dfp = DockerfileParser()

    #open file for reading
    with open(composefile, 'r') as f:
        data = f.read()
        dfp.content = data
        pprint(dfp.baseimage)

        for line in dfp.structure:
            print(line)
            # if line['instruction'] == 'IMAGE':
            #     print(line['instruction'])
            #     print(line['value'])

if __name__ == '__main__':
    main()