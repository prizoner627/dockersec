import requests
import time
import click
import json

from json.decoder import JSONDecodeError

@click.command()							

def main():
    # with open('nvdcve-1.1-2022.json', 'r') as inputFile:
    #     print(inputFile.read())

    f = open('nvdcve-1.1-2022.json')
    data = json.load(f)

    for i in data['CVE_Items']:
        # print(i.keys())
        # dict_keys(['cve', 'configurations', 'impact', 'publishedDate', 'lastModifiedDate'])
        # print(i['cve'].keys())
        print("\n")
        print(i['cve']['CVE_data_meta']['ID'])
        # dict_keys(['data_type', 'data_format', 'data_version', 'CVE_data_meta', 'problemtype', 'references', 'description'])
        # print(i['configurations'].keys())
        # dict_keys(['CVE_data_version', 'nodes'])
        # print(i['impact'].keys())
        # dict_keys([])
        # dict_keys(['baseMetricV3', 'baseMetricV2'])
        # print(i['configurations']['nodes'])
        #some have no nodes
        # print(i['configurations']['nodes'])
        for j in i['configurations']['nodes']:
            # print(j)
            # if j['operator'] == 'OR':
            #     print("OR")
            #     print(j['cpe_match'])
            #     for k in j['cpe_match']:
            #         # [{'vulnerable': True, 'cpe23Uri': 'cpe:2.3:a:samba:cifs-utils:*:*:*:*:*:*:*:*', 'versionEndIncluding': '6.14', 'cpe_name': []}]
            #         print(k['cpe23Uri'])

            if j['operator'] == 'AND':
                print("AND")
                print(j['children'])
                for l in j['children']:
                    print(l)
                    if l['operator'] == 'OR':
                        print("OR")
                        print(l['cpe_match'])
                    if l['operator'] == 'AND':
                        print("AND")
                        print(l['children'])

    # Closing file
    f.close()

if __name__ == '__main__':
    main()